﻿namespace Comme_Chez_Swa.Models.Home.Utility
{
    public enum EnumMenuType
    {
        Ontbijt,
        Lunch,
        Suggestie
    }
}

﻿namespace Comme_Chez_Swa.Models.Home.Utility
{
    public enum EnumGreetingType
    {
        Goeiemorgen,
        Goeiemiddag,
        Welkom,
        Goeienavond
    }
}

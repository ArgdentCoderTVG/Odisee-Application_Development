﻿namespace Comme_Chez_Swa.Models.Home
{
    public abstract class BaseViewModel
    {
        // TODO: If necessary, centralise logic or aspects
    }
}

﻿namespace Demo_EF.Data
{
    public class Department : BaseEntity
    {
        public string Name { get; set; }
    }
}

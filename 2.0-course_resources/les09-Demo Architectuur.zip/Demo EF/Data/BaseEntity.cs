﻿namespace Demo_EF.Data
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}

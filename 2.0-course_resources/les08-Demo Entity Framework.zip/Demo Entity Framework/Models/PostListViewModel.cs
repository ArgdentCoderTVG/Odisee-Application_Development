﻿namespace Demo_Entity_Framework.Models
{
    public class PostListViewModel
    {
        public int Id { get; set; }
        public string Titel { get; set; }
        public string Inhoud { get; set; }
        public DateTime PublicatieDatum { get; set; }
    }
}

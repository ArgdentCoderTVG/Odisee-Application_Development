﻿document.addEventListener("DOMContentLoaded", function () {
    setTimeout(function () {
        document.getElementById("navBar").classList.add("show");
    }, 10000);
});
